package com.example.walkietalkie

import android.annotation.SuppressLint
import android.media.*
import android.util.Log

@SuppressLint("MissingPermission")
class AudioEngine {
    private val SAMPLE_RATE = 8000
    private val CHANNEL_IN = AudioFormat.CHANNEL_IN_MONO
    private val CHANNEL_OUT = AudioFormat.CHANNEL_OUT_MONO
    private val FORMAT = AudioFormat.ENCODING_PCM_16BIT

    private val minBufSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_IN, FORMAT)

    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var isRecording = false

    init {
        // 버퍼 사이즈 유효성 체크
        if (minBufSize != AudioRecord.ERROR && minBufSize != AudioRecord.ERROR_BAD_VALUE) {
            try {
                audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build())
                    .setAudioFormat(AudioFormat.Builder()
                        .setEncoding(FORMAT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(CHANNEL_OUT)
                        .build())
                    .setBufferSizeInBytes(minBufSize * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                audioTrack?.play()
            } catch (e: Exception) {
                Log.e("AudioEngine", "Speaker Init Failed", e)
            }
        }
    }

    fun startRecording(onData: (ByteArray) -> Unit) {
        if (isRecording || minBufSize <= 0) return
        try {
            audioRecord = AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE, CHANNEL_IN, FORMAT, minBufSize)
            if (audioRecord?.state == AudioRecord.STATE_INITIALIZED) {
                isRecording = true
                audioRecord?.startRecording()
                Thread {
                    val buffer = ByteArray(160) // BLE 패킷 최적화
                    while (isRecording) {
                        val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                        if (read > 0) onData(buffer.copyOf())
                    }
                }.start()
            }
        } catch (e: Exception) {
            Log.e("AudioEngine", "Mic Error", e)
        }
    }

    fun stopRecording() {
        isRecording = false
        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (e: Exception) {}
    }

    fun playAudio(data: ByteArray) {
        try { audioTrack?.write(data, 0, data.size) } catch (e: Exception) {}
    }
}