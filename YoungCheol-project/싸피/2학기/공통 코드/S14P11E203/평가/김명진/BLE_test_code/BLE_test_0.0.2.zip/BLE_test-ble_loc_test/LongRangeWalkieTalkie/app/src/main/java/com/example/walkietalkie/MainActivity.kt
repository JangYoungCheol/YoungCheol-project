package com.example.walkietalkie

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import kotlin.math.absoluteValue

class MainActivity : AppCompatActivity(), SensorEventListener, LocationListener, LogFragment.LogFragmentListener {

    private lateinit var bleManager: BleManager
    private var audioEngine: AudioEngine? = null

    private lateinit var viewPager: ViewPager2
    private lateinit var tabLayout: TabLayout
    private var logFragment: LogFragment? = null
    private var radarFragment: RadarFragment? = null

    private var locationManager: LocationManager? = null
    private var myLocation: Location? = null
    private var targetLocation: Location? = null

    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var magnetometer: Sensor? = null
    private val accelerometerReading = FloatArray(3)
    private val magnetometerReading = FloatArray(3)
    private val rotationMatrix = FloatArray(9)
    private val orientationAngles = FloatArray(3)
    private var currentAzimuth: Float = 0f

    private val REQUIRED_PERMISSIONS = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_ADVERTISE,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.RECORD_AUDIO
        )
    } else {
        arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.RECORD_AUDIO
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        viewPager = findViewById(R.id.view_pager)
        tabLayout = findViewById(R.id.tab_layout)
        setupViewPager()

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager

        if (!hasPermissions(REQUIRED_PERMISSIONS)) {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, 1)
        } else {
            startAppFeatures()
        }
    }

    private fun setupViewPager() {
        viewPager.adapter = object : FragmentStateAdapter(this) {
            override fun getItemCount(): Int = 2
            override fun createFragment(position: Int): androidx.fragment.app.Fragment {
                return when (position) {
                    0 -> { logFragment = LogFragment(); logFragment!! }
                    1 -> { radarFragment = RadarFragment(); radarFragment!! }
                    else -> LogFragment()
                }
            }
        }
        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = if (position == 0) "로그/채팅" else "레이더"
        }.attach()
    }

    private fun startAppFeatures() {
        startSensors()
        initBleManager()
        // 오디오 엔진은 버튼 누를 때 시작하므로 초기화만 해둠
        audioEngine = AudioEngine { data ->
            bleManager.broadcastData(Constants.TYPE_AUDIO, data)
        }
    }

    @SuppressLint("MissingPermission")
    private fun initBleManager() {
        bleManager = BleManager(
            this,
            logCallback = { msg -> logFragment?.appendLog(msg) },
            audioCallback = { data -> audioEngine?.playAudio(data) },
            textCallback = { text -> logFragment?.appendLog("[수신] $text") },
            locationCallback = { lat, lng ->
                val loc = Location("target").apply { latitude = lat; longitude = lng }
                targetLocation = loc
                // 위치 받으면 즉시 갱신은 안 하고, 다음 RSSI 수신 때 반영됨
            }
        )

        bleManager.rssiCallback = { deviceId, distance, rssi ->
            val shortId = if (deviceId.length >= 4) deviceId.takeLast(4) else deviceId
            updateRadarUI(shortId, distance)
        }

        bleManager.startAdvertising()
        bleManager.startScanning()
    }

    private fun updateRadarUI(deviceId: String, distance: Float) {
        if (distance <= 0) return

        // 방향 계산
        val target = targetLocation
        val bearingToTarget = if (myLocation != null && target != null) {
            myLocation!!.bearingTo(target)
        } else {
            // 위치 모르면 ID 기반 가상 방향
            (deviceId.hashCode().absoluteValue % 360).toFloat()
        }

        var relativeBearing = bearingToTarget - currentAzimuth
        if (relativeBearing < 0) relativeBearing += 360f

        radarFragment?.updateRadarData(deviceId, distance, relativeBearing)
    }

    @SuppressLint("MissingPermission")
    private fun startSensors() {
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI)
        sensorManager.registerListener(this, magnetometer, SensorManager.SENSOR_DELAY_UI)
        if (hasPermissions(REQUIRED_PERMISSIONS)) {
            locationManager?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 5f, this)
            locationManager?.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000, 5f, this)
        }
    }

    // --- Listeners ---
    override fun onConnectButtonClicked() {
        bleManager.startAdvertising()
        bleManager.startScanning()
        logFragment?.appendLog("재연결 시도...")
    }

    override fun onPttButtonPressed(isPressed: Boolean) {
        if (isPressed) {
            audioEngine?.startRecording()
            logFragment?.appendLog("송신 시작 (마이크 ON)")
        } else {
            audioEngine?.stopRecording()
            logFragment?.appendLog("송신 종료")
        }
    }

    override fun onSendTextClicked(text: String) {
        bleManager.broadcastData(Constants.TYPE_TEXT, text.toByteArray())
        logFragment?.appendLog("[나] $text")
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return
        if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) System.arraycopy(event.values, 0, accelerometerReading, 0, 3)
        else if (event.sensor.type == Sensor.TYPE_MAGNETIC_FIELD) System.arraycopy(event.values, 0, magnetometerReading, 0, 3)

        SensorManager.getRotationMatrix(rotationMatrix, null, accelerometerReading, magnetometerReading)
        SensorManager.getOrientation(rotationMatrix, orientationAngles)

        var azimuth = Math.toDegrees(orientationAngles[0].toDouble()).toFloat()
        if (azimuth < 0) azimuth += 360f
        currentAzimuth = azimuth
    }

    override fun onLocationChanged(location: Location) {
        myLocation = location
        bleManager.broadcastData(Constants.TYPE_LOCATION, "${location.latitude},${location.longitude}".toByteArray())
    }

    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onResume() {
        super.onResume()
        if (hasPermissions(REQUIRED_PERMISSIONS)) startSensors()
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
        locationManager?.removeUpdates(this)
        audioEngine?.stopRecording()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::bleManager.isInitialized) bleManager.disconnect()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            startAppFeatures()
        } else {
            Toast.makeText(this, "권한이 필요합니다.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun hasPermissions(permissions: Array<String>) = permissions.all {
        ActivityCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }
}