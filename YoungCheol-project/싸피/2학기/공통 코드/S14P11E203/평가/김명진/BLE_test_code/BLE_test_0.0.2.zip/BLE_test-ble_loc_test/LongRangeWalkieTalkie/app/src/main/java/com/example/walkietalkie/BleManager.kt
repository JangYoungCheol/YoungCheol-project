package com.example.walkietalkie

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import android.util.Log
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.CRC32
import kotlin.math.pow

object Constants {
    val SERVICE_UUID: UUID = UUID.fromString("0000AAAA-0000-1000-8000-00805f9b34fb")
    val CHAR_UUID: UUID = UUID.fromString("0000BBBB-0000-1000-8000-00805f9b34fb")

    const val TYPE_AUDIO: Byte = 0x01
    const val TYPE_TEXT: Byte = 0x02
    const val TYPE_LOCATION: Byte = 0x03
}

@SuppressLint("MissingPermission")
class BleManager(
    private val context: Context,
    private val logCallback: (String) -> Unit,
    private val audioCallback: (ByteArray) -> Unit,
    private val textCallback: (String) -> Unit,
    private val locationCallback: (Double, Double) -> Unit
) {
    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val adapter: BluetoothAdapter? = bluetoothManager.adapter
    private val scanner: BluetoothLeScanner? = adapter?.bluetoothLeScanner
    private val advertiser: BluetoothLeAdvertiser? = adapter?.bluetoothLeAdvertiser
    private var advertiseCallback: AdvertiseCallback? = null

    // Mesh 연결 관리
    private val connectedGatts = ConcurrentHashMap<String, BluetoothGatt>()
    private val connectedDevices = ConcurrentHashMap<String, BluetoothDevice>()
    private var gattServer: BluetoothGattServer? = null

    // 과부하 방지용 플래그 (현재 쓰고 있는 중인지 확인)
    @Volatile
    private var isWriting = false

    // 패킷 중복 방지 (Loop 방지)
    private val packetCache = object : java.util.LinkedHashMap<Long, Long>(100, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, Long>?): Boolean { return size > 100 }
    }

    var rssiCallback: ((String, Float, Int) -> Unit)? = null
    private val MAX_CONNECTIONS = 4
    private val handler = Handler(Looper.getMainLooper())
    private var isScanning = false
    private var isRssiPolling = false

    init { setupGattServer() }

    // ============================================================================================
    // Public Methods
    // ============================================================================================

    fun startAdvertising() {
        if (adapter == null || !adapter.isEnabled || advertiseCallback != null) return

        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setConnectable(true)
            .setTimeout(0)
            .build()

        val data = AdvertiseData.Builder()
            .setIncludeDeviceName(false)
            .addServiceUuid(ParcelUuid(Constants.SERVICE_UUID))
            .build()

        advertiseCallback = object : AdvertiseCallback() {
            override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) {
                logCallback("Mesh 송출 시작 (Advertising)")
            }
            override fun onStartFailure(errorCode: Int) {
                logCallback("송출 실패: $errorCode")
            }
        }
        advertiser?.startAdvertising(settings, data, advertiseCallback)
    }

    fun startScanning() {
        if (adapter == null || !adapter.isEnabled) return
        startScanInternal()
        startRssiPolling()
    }

    fun broadcastData(type: Byte, content: ByteArray) {
        val packet = ByteArray(1 + content.size)
        packet[0] = type
        System.arraycopy(content, 0, packet, 1, content.size)
        broadcastData(packet)
    }

    fun broadcastData(packet: ByteArray) {
        // 오디오 데이터일 경우, 이전 전송이 안 끝났으면 과감히 드랍 (Flow Control)
        if (packet.isNotEmpty() && packet[0] == Constants.TYPE_AUDIO && isWriting) {
            // Log.v("BleManager", "Audio Packet Dropped (Busy)")
            return
        }

        val checksum = getChecksum(packet)
        packetCache[checksum] = System.currentTimeMillis()
        relayData(null, packet)
    }

    fun disconnect() {
        isScanning = false
        stopRssiPolling()
        scanner?.stopScan(scanCallback)
        advertiser?.stopAdvertising(advertiseCallback)
        advertiseCallback = null

        connectedGatts.values.forEach { it.close() }
        connectedGatts.clear()
        gattServer?.close()
        gattServer = null
    }

    // ============================================================================================
    // Internal Logic
    // ============================================================================================

    private fun setupGattServer() {
        if (gattServer != null) return

        val callback = object : BluetoothGattServerCallback() {
            override fun onConnectionStateChange(device: BluetoothDevice, status: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    connectedDevices[device.address] = device
                    logCallback("연결됨(Server): ${device.address.takeLast(4)}")
                } else {
                    connectedDevices.remove(device.address)
                }
            }

            override fun onCharacteristicWriteRequest(
                device: BluetoothDevice, requestId: Int, characteristic: BluetoothGattCharacteristic,
                preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray
            ) {
                if (responseNeeded) {
                    gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, 0, null)
                }
                processAndRelayData(device.address, value)
            }
        }

        gattServer = bluetoothManager.openGattServer(context, callback)
        val service = BluetoothGattService(Constants.SERVICE_UUID, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        val characteristic = BluetoothGattCharacteristic(
            Constants.CHAR_UUID,
            BluetoothGattCharacteristic.PROPERTY_READ or BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_NOTIFY,
            BluetoothGattCharacteristic.PERMISSION_READ or BluetoothGattCharacteristic.PERMISSION_WRITE
        )
        service.addCharacteristic(characteristic)
        gattServer?.addService(service)
    }

    private fun startScanInternal() {
        if (isScanning) return
        if (connectedGatts.size + connectedDevices.size >= MAX_CONNECTIONS) {
            handler.postDelayed({ startScanInternal() }, 5000)
            return
        }

        val filters = listOf(ScanFilter.Builder().setServiceUuid(ParcelUuid(Constants.SERVICE_UUID)).build())
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setLegacy(false)
            settings.setPhy(ScanSettings.PHY_LE_ALL_SUPPORTED)
        }

        isScanning = true
        scanner?.startScan(filters, settings.build(), scanCallback)

        handler.postDelayed({
            stopScanInternal()
            handler.postDelayed({ startScanInternal() }, 3000)
        }, 10000)
    }

    private fun stopScanInternal() {
        if (!isScanning) return
        scanner?.stopScan(scanCallback)
        isScanning = false
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            if (connectedGatts.containsKey(result.device.address) || connectedDevices.containsKey(result.device.address)) return

            stopScanInternal()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                result.device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
            } else {
                result.device.connectGatt(context, false, gattCallback)
            }
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                connectedGatts[gatt.device.address] = gatt
                logCallback("연결됨(Client): ${gatt.device.address.takeLast(4)}")

                // 1. 대역폭 우선 요청
                gatt.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH)

                // 2. MTU 요청 (중요: 실패 시에도 서비스 탐색 진행하도록 해야 함)
                if (!gatt.requestMtu(517)) {
                    gatt.discoverServices()
                }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                connectedGatts.remove(gatt.device.address)
                gatt.close()
                startScanInternal()
            }
        }

        override fun onMtuChanged(gatt: BluetoothGatt, mtu: Int, status: Int) {
            logCallback("MTU: $mtu")

            // 3. Long Range PHY 요청
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                gatt.setPreferredPhy(
                    BluetoothDevice.PHY_LE_CODED_MASK,
                    BluetoothDevice.PHY_LE_CODED_MASK,
                    BluetoothDevice.PHY_OPTION_NO_PREFERRED
                )
            }
            gatt.discoverServices()
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                val service = gatt.getService(Constants.SERVICE_UUID)
                val characteristic = service?.getCharacteristic(Constants.CHAR_UUID)
                if (characteristic != null) {
                    gatt.setCharacteristicNotification(characteristic, true)
                    val descriptor = characteristic.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))
                    if (descriptor != null) {
                        descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        gatt.writeDescriptor(descriptor)
                    }
                }
                handler.postDelayed({ startScanInternal() }, 1000)
            }
        }

        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            processAndRelayData(gatt.device.address, characteristic.value)
        }

        // 데이터 전송 완료 시 플래그 해제
        override fun onCharacteristicWrite(gatt: BluetoothGatt?, characteristic: BluetoothGattCharacteristic?, status: Int) {
            isWriting = false
        }

        override fun onReadRemoteRssi(gatt: BluetoothGatt?, rssi: Int, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS && gatt != null) {
                val distance = calculateDistance(rssi)
                rssiCallback?.invoke(gatt.device.address, distance, rssi)
            }
        }
    }

    @Synchronized
    private fun processAndRelayData(senderAddress: String, data: ByteArray) {
        val checksum = getChecksum(data)
        if (packetCache.containsKey(checksum)) return
        packetCache[checksum] = System.currentTimeMillis()

        if (data.isNotEmpty()) {
            val content = data.copyOfRange(1, data.size)
            when (data[0]) {
                Constants.TYPE_AUDIO -> audioCallback(content)
                Constants.TYPE_TEXT -> {
                    try { textCallback(String(content)) } catch (_: Exception) {}
                }
                Constants.TYPE_LOCATION -> {
                    try {
                        val parts = String(content).split(",")
                        if (parts.size == 2) locationCallback(parts[0].toDouble(), parts[1].toDouble())
                    } catch (_: Exception) {}
                }
            }
        }
        relayData(senderAddress, data)
    }

    private fun relayData(originalSender: String?, data: ByteArray) {
        // 이미 전송 중이면 오디오는 스킵 (텍스트/위치는 중요하니까 보냄)
        if (data.isNotEmpty() && data[0] == Constants.TYPE_AUDIO && isWriting) return

        isWriting = true

        // Client 연결들에게 전송
        connectedGatts.forEach { (address, gatt) ->
            if (address != originalSender) {
                val char = gatt.getService(Constants.SERVICE_UUID)?.getCharacteristic(Constants.CHAR_UUID)
                if (char != null) {
                    char.value = data
                    char.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                    try { gatt.writeCharacteristic(char) } catch (e: SecurityException) { isWriting = false }
                }
            }
        }

        // Server 연결들에게 전송
        val char = gattServer?.getService(Constants.SERVICE_UUID)?.getCharacteristic(Constants.CHAR_UUID)
        if (char != null) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) char.value = data
            val devices = bluetoothManager.getConnectedDevices(BluetoothProfile.GATT)
            for (dev in devices) {
                if (dev.address != originalSender) {
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            gattServer?.notifyCharacteristicChanged(dev, char, false, data)
                        } else {
                            gattServer?.notifyCharacteristicChanged(dev, char, false)
                        }
                    } catch (e: Exception) { isWriting = false }
                }
            }
        }

        // 전송이 너무 빠르면 플래그가 안 풀릴 수 있으므로 강제 해제 타임아웃
        handler.postDelayed({ isWriting = false }, 50)
    }

    private fun startRssiPolling() {
        if (isRssiPolling) return
        isRssiPolling = true
        val runnable = object : Runnable {
            override fun run() {
                if (!isRssiPolling) return
                connectedGatts.values.forEach { try { it.readRemoteRssi() } catch (_: Exception) {} }
                handler.postDelayed(this, 2000)
            }
        }
        handler.post(runnable)
    }

    private fun stopRssiPolling() { isRssiPolling = false }

    private fun getChecksum(data: ByteArray): Long {
        val crc = CRC32()
        crc.update(data)
        return crc.value
    }

    private fun calculateDistance(rssi: Int): Float {
        if (rssi == 0) return -1.0f
        val ratio = rssi * 1.0 / -59
        return if (ratio < 1.0) ratio.pow(10.0).toFloat()
        else (0.89976 * ratio.pow(7.7095) + 0.111).toFloat()
    }
}