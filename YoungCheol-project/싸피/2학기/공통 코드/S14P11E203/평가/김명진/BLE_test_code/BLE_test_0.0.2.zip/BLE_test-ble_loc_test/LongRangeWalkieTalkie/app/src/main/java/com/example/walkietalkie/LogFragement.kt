package com.example.walkietalkie

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import androidx.fragment.app.Fragment

class LogFragment : Fragment() {

    interface LogFragmentListener {
        fun onConnectButtonClicked()
        fun onPttButtonPressed(isPressed: Boolean)
        fun onSendTextClicked(text: String)
    }

    private var listener: LogFragmentListener? = null
    private var tvLog: TextView? = null
    private var scrollView: ScrollView? = null
    private var btnPtt: Button? = null
    private var etMessage: EditText? = null

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is LogFragmentListener) {
            listener = context
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_log, container, false)

        tvLog = view.findViewById(R.id.tv_log)
        scrollView = view.findViewById(R.id.scroll_view)
        btnPtt = view.findViewById(R.id.btn_ptt)
        etMessage = view.findViewById(R.id.et_message)

        val btnConnect = view.findViewById<Button>(R.id.btn_auto_connect)
        val btnSend = view.findViewById<Button>(R.id.btn_send_text)

        btnConnect.setOnClickListener { listener?.onConnectButtonClicked() }

        btnPtt?.setOnTouchListener { _, event ->
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    listener?.onPttButtonPressed(true)
                    btnPtt?.text = "마이크 끄기 (ON)"
                    true
                }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    listener?.onPttButtonPressed(false)
                    btnPtt?.text = "마이크 켜기 (OFF)"
                    true
                }
                else -> false
            }
        }

        btnSend.setOnClickListener {
            val text = etMessage?.text.toString()
            if (text.isNotEmpty()) {
                listener?.onSendTextClicked(text)
                etMessage?.text?.clear()
            }
        }

        return view
    }

    fun appendLog(msg: String) {
        if (!isAdded || activity == null) return
        activity?.runOnUiThread {
            try {
                tvLog?.append("$msg\n")
                scrollView?.post {
                    scrollView?.fullScroll(View.FOCUS_DOWN)
                }
            } catch (e: Exception) {}
        }
    }
}