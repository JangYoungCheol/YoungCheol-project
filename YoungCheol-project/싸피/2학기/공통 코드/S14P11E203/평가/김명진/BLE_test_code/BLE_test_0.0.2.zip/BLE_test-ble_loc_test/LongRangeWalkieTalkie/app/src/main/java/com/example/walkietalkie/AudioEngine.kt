package com.example.walkietalkie

import android.annotation.SuppressLint
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder

@SuppressLint("MissingPermission")
class AudioEngine(private val onData: (ByteArray) -> Unit) {
    // 8kHz 샘플링
    private val SAMPLE_RATE = 8000
    private val CHANNEL_IN = AudioFormat.CHANNEL_IN_MONO
    private val CHANNEL_OUT = AudioFormat.CHANNEL_OUT_MONO
    private val FORMAT = AudioFormat.ENCODING_PCM_16BIT

    private val minBufSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_IN, FORMAT)

    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null

    @Volatile
    private var isRecording = false

    // 오디오 효과
    private var noiseSuppressor: NoiseSuppressor? = null
    private var automaticGainControl: AutomaticGainControl? = null
    private var acousticEchoCanceler: AcousticEchoCanceler? = null

    // ========================================================================================
    // IMA ADPCM 코덱 테이블 및 상태 변수
    // ========================================================================================
    private val indexTable = intArrayOf(
        -1, -1, -1, -1, 2, 4, 6, 8,
        -1, -1, -1, -1, 2, 4, 6, 8
    )

    private val stepsizeTable = intArrayOf(
        7, 8, 9, 10, 11, 12, 13, 14, 16, 17,
        19, 21, 23, 25, 28, 31, 34, 37, 41, 45,
        50, 55, 60, 66, 73, 80, 88, 97, 107, 118,
        130, 143, 157, 173, 190, 209, 230, 253, 279, 307,
        337, 371, 408, 449, 494, 544, 598, 658, 724, 796,
        876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066,
        2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358,
        5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899,
        15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767
    )

    init {
        setupAudioTrack()
    }

    private fun setupAudioTrack() {
        if (minBufSize == AudioRecord.ERROR || minBufSize == AudioRecord.ERROR_BAD_VALUE) return

        try {
            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build())
                .setAudioFormat(AudioFormat.Builder()
                    .setEncoding(FORMAT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(CHANNEL_OUT)
                    .build())
                // 버퍼 크기를 넉넉하게 잡아서 끊김 방지
                .setBufferSizeInBytes(minBufSize * 4)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            audioTrack?.play()
        } catch (e: Exception) {
            Log.e("AudioEngine", "AudioTrack Init Failed", e)
        }
    }

    fun startRecording() {
        if (isRecording) return
        if (minBufSize == AudioRecord.ERROR || minBufSize == AudioRecord.ERROR_BAD_VALUE) return

        try {
            audioRecord = AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
                .setAudioFormat(AudioFormat.Builder()
                    .setEncoding(FORMAT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(CHANNEL_IN)
                    .build())
                .setBufferSizeInBytes(minBufSize * 2)
                .build()

            if (audioRecord?.state == AudioRecord.STATE_INITIALIZED) {
                applyAudioEffects(audioRecord!!.audioSessionId)
                isRecording = true
                audioRecord?.startRecording()
                Thread { recordAndCompressLoop() }.start()
            }
        } catch (e: Exception) {
            Log.e("AudioEngine", "AudioRecord Init Failed", e)
            stopRecording()
        }
    }

    private fun applyAudioEffects(sessionId: Int) {
        try {
            if (NoiseSuppressor.isAvailable()) {
                noiseSuppressor = NoiseSuppressor.create(sessionId)
                noiseSuppressor?.enabled = true
            }
            if (AutomaticGainControl.isAvailable()) {
                automaticGainControl = AutomaticGainControl.create(sessionId)
                automaticGainControl?.enabled = true
            }
            if (AcousticEchoCanceler.isAvailable()) {
                acousticEchoCanceler = AcousticEchoCanceler.create(sessionId)
                acousticEchoCanceler?.enabled = true
            }
        } catch (e: Exception) {
            Log.w("AudioEngine", "Audio Effect Init Warning", e)
        }
    }

    // ========================================================================================
    // 압축 및 전송 루프
    // ========================================================================================
    private fun recordAndCompressLoop() {
        // BLE MTU 517 바이트를 최대한 활용하기 위한 전략
        // ADPCM은 4:1 압축률을 가짐.
        // 헤더 4바이트를 제외하고 약 500바이트의 압축 데이터를 보내려면
        // 원본 PCM 데이터는 2000바이트(1000 샘플) 정도가 필요함.
        // 1000 샘플 / 8000Hz = 125ms 분량의 오디오를 한 패킷에 담아 보냄.

        val pcmSamplesPerPacket = 800 // 100ms 분량
        val pcmBufferSizeInBytes = pcmSamplesPerPacket * 2 // Short는 2바이트
        val pcmBuffer = ByteArray(pcmBufferSizeInBytes)
        val shortBuffer = ShortArray(pcmSamplesPerPacket)

        while (isRecording) {
            // 1. PCM 데이터 읽기 (Blocking)
            val readBytes = audioRecord?.read(pcmBuffer, 0, pcmBufferSizeInBytes) ?: 0

            if (readBytes == pcmBufferSizeInBytes) {
                // 2. ByteArray -> ShortArray 변환 (Little Endian)
                ByteBuffer.wrap(pcmBuffer).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shortBuffer)

                // 3. ADPCM 압축 수행
                // 압축 후 크기: 4바이트 헤더 + (800 샘플 / 2) = 404 바이트
                val compressedData = encodeAdpcm(shortBuffer, readBytes / 2)

                // 4. 전송
                onData(compressedData)
            }
        }
    }

    fun stopRecording() {
        isRecording = false
        try {
            noiseSuppressor?.release()
            automaticGainControl?.release()
            acousticEchoCanceler?.release()
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
        } catch (e: Exception) {}
    }

    // ========================================================================================
    // 수신 및 재생
    // ========================================================================================
    fun playAudio(compressedData: ByteArray) {
        try {
            if (audioTrack != null && audioTrack!!.state == AudioTrack.STATE_INITIALIZED) {
                // 1. ADPCM 압축 해제
                val decodedPcmShorts = decodeAdpcm(compressedData)

                // 2. ShortArray -> ByteArray 변환
                val pcmBytes = ByteArray(decodedPcmShorts.size * 2)
                ByteBuffer.wrap(pcmBytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(decodedPcmShorts)

                // 3. 재생
                audioTrack?.write(pcmBytes, 0, pcmBytes.size)
            } else {
                setupAudioTrack()
            }
        } catch (e: Exception) {
            Log.e("AudioEngine", "Play Error", e)
        }
    }

    // ========================================================================================
    // IMA ADPCM 알고리즘 구현 (순수 코틀린)
    // ========================================================================================

    // [인코더] PCM ShortArray -> ADPCM ByteArray
    // 패킷 손실에 대비해 각 패킷의 헤더에 시작값(Predictor, Index)을 포함시키는 Block 방식
    private fun encodeAdpcm(pcmData: ShortArray, len: Int): ByteArray {
        val outSize = 4 + (len / 2) // 헤더 4바이트 + 데이터(2샘플당 1바이트)
        val out = ByteArray(outSize)

        var predictor = if (len > 0) pcmData[0].toInt() else 0
        var stepIndex = 0
        var byteIndex = 4 // 헤더 이후부터 데이터 시작

        // 헤더 작성: 초기 예측값(16bit) + 초기 Step Index(8bit)
        out[0] = (predictor and 0xFF).toByte()
        out[1] = ((predictor shr 8) and 0xFF).toByte()
        out[2] = stepIndex.toByte()
        out[3] = 0 // 예약

        // 데이터 압축 루프
        for (i in 0 until len step 2) {
            // 첫 번째 샘플 (하위 4비트)
            var valpred = predictor
            var index = stepIndex
            var step = stepsizeTable[index]
            var diff = pcmData[i] - valpred
            var sign = if (diff < 0) 8 else 0
            if (diff < 0) diff = -diff

            var delta = 0
            var vpdiff = (step shr 3)
            if (diff >= step) { delta = 4; diff -= step; vpdiff += step }
            step = step shr 1
            if (diff >= step) { delta = delta or 2; diff -= step; vpdiff += step }
            step = step shr 1
            if (diff >= step) { delta = delta or 1; vpdiff += step }

            if ((sign and 8) != 0) valpred -= vpdiff else valpred += vpdiff

            // 클램핑
            if (valpred > 32767) valpred = 32767
            else if (valpred < -32768) valpred = -32768
            predictor = valpred

            stepIndex = index + indexTable[delta]
            if (stepIndex < 0) stepIndex = 0
            else if (stepIndex > 88) stepIndex = 88
            val nibble1 = sign or delta

            // 두 번째 샘플 (상위 4비트)이 존재한다면 처리
            var nibble2 = 0
            if (i + 1 < len) {
                valpred = predictor
                index = stepIndex
                step = stepsizeTable[index]
                diff = pcmData[i + 1] - valpred
                sign = if (diff < 0) 8 else 0
                if (diff < 0) diff = -diff

                delta = 0
                vpdiff = (step shr 3)
                if (diff >= step) { delta = 4; diff -= step; vpdiff += step }
                step = step shr 1
                if (diff >= step) { delta = delta or 2; diff -= step; vpdiff += step }
                step = step shr 1
                if (diff >= step) { delta = delta or 1; vpdiff += step }

                if ((sign and 8) != 0) valpred -= vpdiff else valpred += vpdiff

                if (valpred > 32767) valpred = 32767
                else if (valpred < -32768) valpred = -32768
                predictor = valpred

                stepIndex = index + indexTable[delta]
                if (stepIndex < 0) stepIndex = 0
                else if (stepIndex > 88) stepIndex = 88
                nibble2 = sign or delta
            }

            out[byteIndex++] = ((nibble2 shl 4) or nibble1).toByte()
        }
        return out
    }

    // [디코더] ADPCM ByteArray -> PCM ShortArray
    private fun decodeAdpcm(adpcmData: ByteArray): ShortArray {
        if (adpcmData.size < 4) return ShortArray(0)

        // 헤더 읽기
        var predictor = (adpcmData[0].toInt() and 0xFF) or ((adpcmData[1].toInt() shl 8))
        // Short형으로 부호 복원
        if (predictor > 32767) predictor -= 65536

        var stepIndex = adpcmData[2].toInt()
        if (stepIndex < 0) stepIndex = 0
        else if (stepIndex > 88) stepIndex = 88

        val dataLen = (adpcmData.size - 4) * 2
        val out = ShortArray(dataLen)
        var outIndex = 0

        for (i in 4 until adpcmData.size) {
            val byteVal = adpcmData[i].toInt()

            // 하위 4비트 처리
            var delta = byteVal and 0x0F
            var step = stepsizeTable[stepIndex]
            var vpdiff = step shr 3
            if ((delta and 4) != 0) vpdiff += step
            if ((delta and 2) != 0) vpdiff += (step shr 1)
            if ((delta and 1) != 0) vpdiff += (step shr 2)

            if ((delta and 8) != 0) predictor -= vpdiff
            else predictor += vpdiff

            if (predictor > 32767) predictor = 32767
            else if (predictor < -32768) predictor = -32768
            out[outIndex++] = predictor.toShort()

            stepIndex += indexTable[delta and 7]
            if (stepIndex < 0) stepIndex = 0
            else if (stepIndex > 88) stepIndex = 88

            // 상위 4비트 처리
            delta = (byteVal shr 4) and 0x0F
            step = stepsizeTable[stepIndex]
            vpdiff = step shr 3
            if ((delta and 4) != 0) vpdiff += step
            if ((delta and 2) != 0) vpdiff += (step shr 1)
            if ((delta and 1) != 0) vpdiff += (step shr 2)

            if ((delta and 8) != 0) predictor -= vpdiff
            else predictor += vpdiff

            if (predictor > 32767) predictor = 32767
            else if (predictor < -32768) predictor = -32768
            out[outIndex++] = predictor.toShort()

            stepIndex += indexTable[delta and 7]
            if (stepIndex < 0) stepIndex = 0
            else if (stepIndex > 88) stepIndex = 88
        }
        return out
    }
}