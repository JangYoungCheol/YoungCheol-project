package com.example.walkietalkie

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class RadarView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var centerX: Float = 0f
    private var centerY: Float = 0f
    private var maxRadius: Float = 0f

    // 다중 타겟 저장을 위한 데이터 클래스
    data class RadarTarget(
        val distance: Float,
        val bearing: Float,
        val timestamp: Long = System.currentTimeMillis()
    )

    // ID를 키로 하여 여러 기기 위치 저장 (동시성 문제 방지용 ConcurrentHashMap)
    private val targets = ConcurrentHashMap<String, RadarTarget>()

    // 레이더 최대 표시 거리 (기본 50m로 설정)
    private val maxDisplayRangeMeters = 50f

    init {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        centerX = w / 2f
        centerY = h / 2f
        maxRadius = min(w, h) / 2f * 0.9f
    }

    // 외부에서 호출하는 데이터 업데이트 함수
    fun updateTargetData(id: String, distance: Float, bearing: Float) {
        targets[id] = RadarTarget(distance, bearing, System.currentTimeMillis())
        invalidate() // 화면 다시 그리기 요청
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // 1. 레이더 배경 그리기 (녹색 동심원)
        paint.color = Color.GREEN
        paint.style = Paint.Style.STROKE
        paint.alpha = 100
        canvas.drawCircle(centerX, centerY, maxRadius, paint)
        canvas.drawCircle(centerX, centerY, maxRadius * 0.66f, paint)
        canvas.drawCircle(centerX, centerY, maxRadius * 0.33f, paint)

        // 십자선
        canvas.drawLine(centerX, centerY - maxRadius, centerX, centerY + maxRadius, paint)
        canvas.drawLine(centerX - maxRadius, centerY, centerX + maxRadius, centerY, paint)

        // 2. 타겟들 그리기
        val currentTime = System.currentTimeMillis()

        // 맵에 저장된 모든 기기 순회
        val iterator = targets.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            val id = entry.key
            val target = entry.value

            // 15초 이상 업데이트 없는 기기는 삭제 (사라진 것으로 간주)
            if (currentTime - target.timestamp > 15000) {
                iterator.remove()
                continue
            }

            // 거리 비율 계산 (최대 거리 넘어가면 테두리에 걸치게)
            val normalizedDistance = min(target.distance / maxDisplayRangeMeters, 1.0f)
            val targetRadius = maxRadius * normalizedDistance

            // 각도 계산 (12시 방향이 0도, 시계방향)
            // Android Canvas는 3시가 0도이므로 -90도 보정
            val angleRad = Math.toRadians((target.bearing - 90.0))

            val targetX = centerX + (targetRadius * cos(angleRad)).toFloat()
            val targetY = centerY + (targetRadius * sin(angleRad)).toFloat()

            // 점 그리기 (빨간색)
            paint.style = Paint.Style.FILL
            paint.color = Color.RED
            paint.alpha = 255
            canvas.drawCircle(targetX, targetY, 15f, paint)

            // ID 텍스트 그리기
            paint.color = Color.WHITE
            paint.textSize = 30f
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText(id, targetX, targetY - 25f, paint)

            // 거리 텍스트 그리기
            paint.textSize = 24f
            paint.color = Color.LTGRAY
            canvas.drawText("%.1fm".format(target.distance), targetX, targetY + 35f, paint)
        }

        // 3. 중앙(나) 표시
        paint.style = Paint.Style.FILL
        paint.color = Color.YELLOW
        canvas.drawCircle(centerX, centerY, 10f, paint)
    }
}