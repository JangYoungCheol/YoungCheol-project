package com.example.walkietalkie

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import java.util.concurrent.ConcurrentHashMap

class RadarFragment : Fragment() {

    private var radarView: RadarView? = null
    private var tvInfo: TextView? = null

    // 감지된 타겟들의 정보를 저장할 맵 (ID -> 정보문자열)
    private val targetInfoMap = ConcurrentHashMap<String, String>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_radar, container, false)
        radarView = view.findViewById(R.id.radar_view)
        tvInfo = view.findViewById(R.id.tv_radar_info)
        return view
    }

    // 메인 액티비티에서 거리/방향/이름 정보 업데이트 시 호출
    fun updateRadarData(id: String, distance: Float, relativeBearing: Float) {
        activity?.runOnUiThread {
            // 1. 레이더 뷰에 타겟 업데이트 (Visual)
            radarView?.updateTargetData(id, distance, relativeBearing)

            // 2. 텍스트 정보 업데이트 (Text List)
            val info = "ID: $id | %.1fm".format(distance)
            targetInfoMap[id] = info

            // 맵에 있는 모든 기기 정보를 줄바꿈으로 연결해서 표시
            val sb = StringBuilder()
            sb.append("감지된 기기: ${targetInfoMap.size}대\n")

            // 거리순 정렬 등은 복잡하므로 일단 입력된 순서(Key)대로 표시
            targetInfoMap.values.forEach {
                sb.append(it).append("\n")
            }

            tvInfo?.text = sb.toString()
        }
    }
}